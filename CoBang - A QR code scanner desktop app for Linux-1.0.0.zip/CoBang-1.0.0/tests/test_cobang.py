def test_parse_wifi():
    data = 'WIFI:S:royaltea tret ;T:WPA;P:160108hp;H:false;;'
    return
